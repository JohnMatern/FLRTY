import { Component } from 'react';
import { Grid } from "@material-ui/core";

class Footer extends Component {
  state = {}
  render() {
    return (
      <div>
        <Grid container className="footer">
          Footer
        </Grid>
      </div>
    );
  }
}

export default Footer;