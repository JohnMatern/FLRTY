import { Component } from 'react';
import { Grid } from "@material-ui/core";

class Home extends Component {
  state = {}
  render() {
    return (
      <div>
        <Grid container className="home">
          Home
        </Grid>
      </div>
    );
  }
}

export default Home;